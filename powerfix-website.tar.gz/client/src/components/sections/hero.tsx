import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { COMPANY_INFO } from "@/lib/constants";

const Hero = () => {
  return (
    <section className="relative bg-powerfix-dark overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1621905251189-08b45d6a269e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=2069&q=80')"
        }}
      >
        <div className="absolute inset-0 bg-powerfix-dark bg-opacity-75"></div>
      </div>
      
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            High-Performance Construction
            <span className="block text-powerfix-yellow">Adhesive Solutions</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Made in Rwanda with Turkish technology, PowerFix delivers superior adhesive solutions for construction professionals. Easy to apply, strong bonding, and weather-resistant.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/products">
              <Button 
                size="lg" 
                className="bg-powerfix-yellow hover:bg-powerfix-yellow/90 text-powerfix-dark px-8 py-3 text-lg font-semibold"
              >
                Discover Our Products
              </Button>
            </Link>
            <Link href="/contact">
              <Button 
                size="lg" 
                className="bg-powerfix-red hover:bg-powerfix-red/90 text-white px-8 py-3 text-lg font-semibold"
              >
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
