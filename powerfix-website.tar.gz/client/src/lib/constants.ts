export const COMPANY_INFO = {
  name: "PowerFix",
  tagline: "The world of adhesive",
  slogan: "High-Performance Construction Adhesive Solutions",
  founded: "2016",
  location: "Kigali, Rwanda",
  mission: "Delivering durable and innovative adhesive solutions with expert service.",
  vision: "To be the preferred brand for high-performance construction adhesives.",
  
  contact: {
    address: "Gisozi, Gakinjiro, Umukindo Plaza, KN 78, Kigali - Rwanda",
    phone1: "+250 788 308 285",
    phone2: "+250 788 309 854",
    email: "info@powerfix.rw",
    website: "powerfix.rw",
    whatsapp: "250788308285"
  },
  
  social: {
    facebook: "powerfixadhesive",
    instagram: "powerfixadhesive",
    linkedin: "powerfix-rwanda"
  }
};

export const PRODUCTS = [
  {
    id: "tile-ceramic",
    name: "Tile & Ceramic Adhesive",
    description: "High-bond strength tile adhesive for internal and external applications",
    features: ["Indoor & Outdoor Use", "Sag-Resistant", "Superior Water Retention", "Easy to apply - only mix with water"],
    package: "25kg",
    icon: "Layers"
  },
  {
    id: "granite-marble",
    name: "Granite & Marble Adhesive",
    description: "Specially formulated for heavy stone installation",
    features: ["Heavy Stone Support", "Natural Stone Compatible", "Professional Grade", "Strong bonding capability"],
    package: "25kg",
    icon: "Mountain"
  },
  {
    id: "pool-humidity",
    name: "Swimming Pool & Humidity Adhesive",
    description: "Water-resistant adhesive for pools and wet areas",
    features: ["Waterproof Formula", "Pool Applications", "Humidity Resistant", "Wet area compatible"],
    package: "25kg",
    icon: "Waves"
  },
  {
    id: "grout",
    name: "Grout",
    description: "Durable grout for all types of tiles",
    features: ["All Tile Types", "Durable Finish", "Professional Results", "Long-lasting performance"],
    package: "25kg",
    icon: "Brush"
  }
];

export const REFERENCE_PROJECTS = [
  {
    id: "kcc",
    name: "Kigali Convention Center",
    description: "Premium tile and ceramic adhesive solutions for this iconic venue",
    image: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
  },
  {
    id: "bk-arena",
    name: "BK Arena",
    description: "High-performance adhesives for sports facility construction",
    image: "https://images.unsplash.com/photo-1571731956672-f2b94d7dd0cb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
  },
  {
    id: "amahoro",
    name: "Amahoro Stadium",
    description: "Specialized adhesive solutions for stadium renovation projects",
    image: "https://images.unsplash.com/photo-1459865264687-595d652de67e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
  },
  {
    id: "sheraton",
    name: "Four Points by Sheraton",
    description: "Premium hospitality project with high-quality adhesive solutions",
    image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
  },
  {
    id: "intare",
    name: "Intare Conference Arena",
    description: "Conference facility construction with specialized adhesive applications",
    image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
  }
];

export const WHY_CHOOSE_POWERFIX = [
  "Reliable product performance",
  "Expert customer support", 
  "Innovation in construction solutions",
  "Turkish technology and quality",
  "Made in Rwanda for local conditions",
  "Proven track record in major projects"
];
